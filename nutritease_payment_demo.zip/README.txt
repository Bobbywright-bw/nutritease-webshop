
NutriEase Webshop – Payment Demo (School Project)

Instructions:
1. Replace the Stripe links with your own Payment Links.
2. Upload this folder to your GitHub repository.
3. Make sure index.html stays named exactly 'index.html'.
4. Add real product images inside the 'images' folder.

Note:
Payments are handled via hosted checkout pages (Stripe).
